import React, { useState, useEffect } from 'react';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card, CardContent, CardHeader } from '@/components/ui/card';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Button } from '@/components/ui/button';
import { Tabs, TabsList, TabsTrigger, TabsContent } from '@/components/ui/tabs';
import { formatNumber, calculateCompoundInterest } from '@/utils/calculatorUtils';

export interface LoanData {
  paymentNumber: number;
  payment: number;
  principal: number;
  interest: number;
  remainingBalance: number;
}

export const MortgageCalculator = () => {
  const [loanAmount, setLoanAmount] = useState<string>("300000");
  const [interestRate, setInterestRate] = useState<string>("4.5");
  const [loanTerm, setLoanTerm] = useState<string>("30");
  const [monthlyPayment, setMonthlyPayment] = useState<number>(0);
  const [totalInterest, setTotalInterest] = useState<number>(0);
  const [totalPayment, setTotalPayment] = useState<number>(0);
  const [amortizationSchedule, setAmortizationSchedule] = useState<LoanData[]>([]);
  const [viewMode, setViewMode] = useState<string>("summary");

  useEffect(() => {
    calculateMortgage();
  }, [loanAmount, interestRate, loanTerm]);

  const calculateMortgage = () => {
    const principal = parseFloat(loanAmount) || 0;
    const annualRate = (parseFloat(interestRate) || 0) / 100;
    const years = parseInt(loanTerm) || 30;
    
    // Monthly rate and number of payments
    const monthlyRate = annualRate / 12;
    const payments = years * 12;
    
    // Calculate monthly payment: P × [ i × (1 + i)^N ] / [ (1 + i)^N – 1 ]
    let monthly = 0;
    if (monthlyRate > 0) {
      monthly = principal * (monthlyRate * Math.pow(1 + monthlyRate, payments)) / 
                (Math.pow(1 + monthlyRate, payments) - 1);
    } else {
      monthly = principal / payments;
    }
    
    setMonthlyPayment(monthly);
    
    // Calculate total interest
    const totalPaid = monthly * payments;
    setTotalPayment(totalPaid);
    setTotalInterest(totalPaid - principal);
    
    // Generate amortization schedule
    generateAmortizationSchedule(principal, monthlyRate, payments, monthly);
  };

  const generateAmortizationSchedule = (principal: number, monthlyRate: number, payments: number, monthlyPayment: number) => {
    let schedule: LoanData[] = [];
    let balance = principal;
    let totalInterestPaid = 0;
    
    for (let i = 1; i <= payments; i++) {
      const interestPayment = balance * monthlyRate;
      const principalPayment = monthlyPayment - interestPayment;
      
      balance -= principalPayment;
      totalInterestPaid += interestPayment;
      
      // Only include yearly entries (every 12 months) to keep the schedule manageable
      if (i % 12 === 0 || i === 1 || i === payments) {
        schedule.push({
          paymentNumber: i,
          payment: monthlyPayment,
          principal: principalPayment,
          interest: interestPayment,
          remainingBalance: Math.max(0, balance)
        });
      }
    }
    
    setAmortizationSchedule(schedule);
  };

  return (
    <div>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
        <div>
          <Card>
            <CardHeader>
              <h3 className="text-lg font-semibold">Mortgage Details</h3>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="loan-amount">Loan Amount ($)</Label>
                  <Input 
                    id="loan-amount" 
                    type="number"
                    value={loanAmount}
                    onChange={(e) => setLoanAmount(e.target.value)}
                  />
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="interest-rate">Annual Interest Rate (%)</Label>
                  <Input 
                    id="interest-rate" 
                    type="number"
                    value={interestRate}
                    onChange={(e) => setInterestRate(e.target.value)}
                    step="0.01"
                  />
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="loan-term">Loan Term (years)</Label>
                  <Select value={loanTerm} onValueChange={setLoanTerm}>
                    <SelectTrigger>
                      <SelectValue placeholder="Select term" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="10">10 years</SelectItem>
                      <SelectItem value="15">15 years</SelectItem>
                      <SelectItem value="20">20 years</SelectItem>
                      <SelectItem value="25">25 years</SelectItem>
                      <SelectItem value="30">30 years</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
        
        <div>
          <Card>
            <CardHeader>
              <h3 className="text-lg font-semibold">Mortgage Summary</h3>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="p-4 bg-muted rounded-md">
                  <div className="text-sm text-muted-foreground">Monthly Payment</div>
                  <div className="text-2xl font-bold">${formatNumber(monthlyPayment)}</div>
                </div>
                
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <div className="text-sm text-muted-foreground">Total Principal</div>
                    <div className="font-semibold">${formatNumber(parseFloat(loanAmount) || 0)}</div>
                  </div>
                  <div>
                    <div className="text-sm text-muted-foreground">Total Interest</div>
                    <div className="font-semibold">${formatNumber(totalInterest)}</div>
                  </div>
                </div>
                
                <div className="p-4 bg-muted/50 rounded-md">
                  <div className="text-sm text-muted-foreground">Total Cost</div>
                  <div className="text-lg font-bold">${formatNumber(totalPayment)}</div>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
      
      <div className="mt-8">
        <Tabs value={viewMode} onValueChange={setViewMode}>
          <TabsList className="grid w-full grid-cols-2">
            <TabsTrigger value="summary">Payment Summary</TabsTrigger>
            <TabsTrigger value="schedule">Amortization Schedule</TabsTrigger>
          </TabsList>
          <TabsContent value="summary">
            <Card>
              <CardContent className="pt-6">
                <div className="text-center mb-6">
                  <h3 className="text-lg font-semibold">Payment Breakdown</h3>
                  <p className="text-muted-foreground">Where your money goes over {loanTerm} years</p>
                </div>
                <div className="flex justify-center items-center gap-8">
                  <div className="text-center">
                    <div className="w-32 h-32 rounded-full bg-primary flex items-center justify-center mb-2">
                      <div className="text-primary-foreground">
                        <div className="text-xs">Principal</div>
                        <div className="font-bold">{formatNumber((parseFloat(loanAmount) / totalPayment * 100) || 0)}%</div>
                      </div>
                    </div>
                    <div>${formatNumber(parseFloat(loanAmount) || 0)}</div>
                  </div>
                  <div className="text-center">
                    <div className="w-32 h-32 rounded-full bg-secondary flex items-center justify-center mb-2">
                      <div className="text-secondary-foreground">
                        <div className="text-xs">Interest</div>
                        <div className="font-bold">{formatNumber((totalInterest / totalPayment * 100) || 0)}%</div>
                      </div>
                    </div>
                    <div>${formatNumber(totalInterest)}</div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
          <TabsContent value="schedule">
            <Card>
              <CardContent className="pt-6">
                <div className="text-sm mb-4">
                  Showing yearly snapshots of your loan amortization schedule
                </div>
                <div className="overflow-x-auto">
                  <table className="w-full border-collapse">
                    <thead>
                      <tr className="border-b">
                        <th className="text-left py-2">Payment</th>
                        <th className="text-left py-2">Payment Amount</th>
                        <th className="text-left py-2">Principal</th>
                        <th className="text-left py-2">Interest</th>
                        <th className="text-left py-2">Remaining Balance</th>
                      </tr>
                    </thead>
                    <tbody>
                      {amortizationSchedule.map((entry) => (
                        <tr key={entry.paymentNumber} className="border-b">
                          <td className="py-2">{entry.paymentNumber}</td>
                          <td className="py-2">${formatNumber(entry.payment)}</td>
                          <td className="py-2">${formatNumber(entry.principal)}</td>
                          <td className="py-2">${formatNumber(entry.interest)}</td>
                          <td className="py-2">${formatNumber(entry.remainingBalance)}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
};

export const AutoLoanCalculator = () => {
  const [loanAmount, setLoanAmount] = useState<string>("30000");
  const [interestRate, setInterestRate] = useState<string>("5.0");
  const [loanTerm, setLoanTerm] = useState<string>("60"); // Default 60 months (5 years)
  const [downPayment, setDownPayment] = useState<string>("0");
  const [monthlyPayment, setMonthlyPayment] = useState<number>(0);
  const [totalInterest, setTotalInterest] = useState<number>(0);
  const [totalCost, setTotalCost] = useState<number>(0);

  useEffect(() => {
    calculateAutoLoan();
  }, [loanAmount, interestRate, loanTerm, downPayment]);

  const calculateAutoLoan = () => {
    const principal = (parseFloat(loanAmount) || 0) - (parseFloat(downPayment) || 0);
    const annualRate = (parseFloat(interestRate) || 0) / 100;
    const months = parseInt(loanTerm) || 60;
    
    // Monthly rate
    const monthlyRate = annualRate / 12;
    
    // Calculate monthly payment: P × [ i × (1 + i)^N ] / [ (1 + i)^N – 1 ]
    let monthly = 0;
    if (monthlyRate > 0) {
      monthly = principal * (monthlyRate * Math.pow(1 + monthlyRate, months)) / 
                (Math.pow(1 + monthlyRate, months) - 1);
    } else {
      monthly = principal / months;
    }
    
    setMonthlyPayment(monthly);
    
    // Calculate total interest
    const totalPaid = monthly * months;
    setTotalCost(totalPaid + parseFloat(downPayment));
    setTotalInterest(totalPaid - principal);
  };

  return (
    <div>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
        <div>
          <Card>
            <CardHeader>
              <h3 className="text-lg font-semibold">Auto Loan Details</h3>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="auto-loan-amount">Car Price ($)</Label>
                  <Input 
                    id="auto-loan-amount" 
                    type="number"
                    value={loanAmount}
                    onChange={(e) => setLoanAmount(e.target.value)}
                  />
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="down-payment">Down Payment ($)</Label>
                  <Input 
                    id="down-payment" 
                    type="number"
                    value={downPayment}
                    onChange={(e) => setDownPayment(e.target.value)}
                  />
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="auto-interest-rate">Annual Interest Rate (%)</Label>
                  <Input 
                    id="auto-interest-rate" 
                    type="number"
                    value={interestRate}
                    onChange={(e) => setInterestRate(e.target.value)}
                    step="0.01"
                  />
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="auto-loan-term">Loan Term (months)</Label>
                  <Select value={loanTerm} onValueChange={setLoanTerm}>
                    <SelectTrigger>
                      <SelectValue placeholder="Select term" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="36">36 months (3 years)</SelectItem>
                      <SelectItem value="48">48 months (4 years)</SelectItem>
                      <SelectItem value="60">60 months (5 years)</SelectItem>
                      <SelectItem value="72">72 months (6 years)</SelectItem>
                      <SelectItem value="84">84 months (7 years)</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
        
        <div>
          <Card>
            <CardHeader>
              <h3 className="text-lg font-semibold">Auto Loan Summary</h3>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="p-4 bg-muted rounded-md">
                  <div className="text-sm text-muted-foreground">Monthly Payment</div>
                  <div className="text-2xl font-bold">${formatNumber(monthlyPayment)}</div>
                </div>
                
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <div className="text-sm text-muted-foreground">Loan Amount</div>
                    <div className="font-semibold">${formatNumber((parseFloat(loanAmount) || 0) - (parseFloat(downPayment) || 0))}</div>
                  </div>
                  <div>
                    <div className="text-sm text-muted-foreground">Down Payment</div>
                    <div className="font-semibold">${formatNumber(parseFloat(downPayment) || 0)}</div>
                  </div>
                </div>
                
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <div className="text-sm text-muted-foreground">Total Interest</div>
                    <div className="font-semibold">${formatNumber(totalInterest)}</div>
                  </div>
                  <div>
                    <div className="text-sm text-muted-foreground">Loan Term</div>
                    <div className="font-semibold">{Math.floor(parseInt(loanTerm) / 12)} years ({loanTerm} months)</div>
                  </div>
                </div>
                
                <div className="p-4 bg-muted/50 rounded-md">
                  <div className="text-sm text-muted-foreground">Total Cost</div>
                  <div className="text-lg font-bold">${formatNumber(totalCost)}</div>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
};

export const CompoundInterestCalculator = () => {
  const [principal, setPrincipal] = useState<string>("10000");
  const [rate, setRate] = useState<string>("5");
  const [time, setTime] = useState<string>("10");
  const [compoundingFrequency, setCompoundingFrequency] = useState<string>("12");
  const [futureValue, setFutureValue] = useState<number>(0);
  const [totalInterest, setTotalInterest] = useState<number>(0);

  useEffect(() => {
    calculateCompoundInterestResult();
  }, [principal, rate, time, compoundingFrequency]);

  const calculateCompoundInterestResult = () => {
    const p = parseFloat(principal) || 0;
    const r = (parseFloat(rate) || 0) / 100;
    const t = parseFloat(time) || 0;
    const n = parseFloat(compoundingFrequency) || 1;
    
    // Calculate compound interest: A = P(1 + r/n)^(nt)
    const futureVal = p * Math.pow(1 + r/n, n * t);
    setFutureValue(futureVal);
    setTotalInterest(futureVal - p);
  };

  const frequencyOptions = [
    { value: "1", label: "Annually (1/year)" },
    { value: "2", label: "Semi-annually (2/year)" },
    { value: "4", label: "Quarterly (4/year)" },
    { value: "12", label: "Monthly (12/year)" },
    { value: "365", label: "Daily (365/year)" },
  ];

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
      <div>
        <Card>
          <CardHeader>
            <h3 className="text-lg font-semibold">Investment Details</h3>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="principal">Initial Investment ($)</Label>
                <Input
                  id="principal"
                  type="number"
                  value={principal}
                  onChange={(e) => setPrincipal(e.target.value)}
                />
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="interest-rate">Annual Interest Rate (%)</Label>
                <Input
                  id="interest-rate"
                  type="number"
                  value={rate}
                  onChange={(e) => setRate(e.target.value)}
                  step="0.01"
                />
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="time-period">Time Period (years)</Label>
                <Input
                  id="time-period"
                  type="number"
                  value={time}
                  onChange={(e) => setTime(e.target.value)}
                />
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="compounding-frequency">Compounding Frequency</Label>
                <Select
                  value={compoundingFrequency}
                  onValueChange={setCompoundingFrequency}
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Select frequency" />
                  </SelectTrigger>
                  <SelectContent>
                    {frequencyOptions.map((option) => (
                      <SelectItem key={option.value} value={option.value}>
                        {option.label}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
      
      <div>
        <Card>
          <CardHeader>
            <h3 className="text-lg font-semibold">Investment Growth</h3>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div className="p-4 bg-muted rounded-md">
                <div className="text-sm text-muted-foreground">Future Value</div>
                <div className="text-2xl font-bold">${formatNumber(futureValue)}</div>
              </div>
              
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <div className="text-sm text-muted-foreground">Initial Investment</div>
                  <div className="font-semibold">${formatNumber(parseFloat(principal) || 0)}</div>
                </div>
                <div>
                  <div className="text-sm text-muted-foreground">Total Interest Earned</div>
                  <div className="font-semibold">${formatNumber(totalInterest)}</div>
                </div>
              </div>
              
              <div className="p-4 bg-muted/50 rounded-md">
                <div className="text-sm text-muted-foreground">Interest to Principal Ratio</div>
                <div className="text-lg font-bold">
                  {formatNumber((totalInterest / (parseFloat(principal) || 1)) * 100)}%
                </div>
                <div className="text-sm text-muted-foreground mt-1">
                  For each $1 invested, you earn ${formatNumber(totalInterest / (parseFloat(principal) || 1))}
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
};
