
import { useState, useEffect } from 'react';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card, CardContent } from '@/components/ui/card';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Tabs, TabsList, TabsTrigger, TabsContent } from '@/components/ui/tabs';
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group';
import { Button } from '@/components/ui/button';
import { calculateBMI, calculateCalories } from '@/utils/calculatorUtils';

export const BMICalculator = () => {
  const [weight, setWeight] = useState<string>("");
  const [height, setHeight] = useState<string>("");
  const [unit, setUnit] = useState<'metric' | 'imperial'>('metric');
  const [heightFt, setHeightFt] = useState<string>("");
  const [heightIn, setHeightIn] = useState<string>("");
  const [bmi, setBmi] = useState<number | null>(null);
  const [weightCategory, setWeightCategory] = useState<string>("");

  useEffect(() => {
    calculateBmiResult();
  }, [weight, height, heightFt, heightIn, unit]);

  const calculateBmiResult = () => {
    if (unit === 'metric' && weight && height) {
      const weightVal = parseFloat(weight);
      const heightVal = parseFloat(height) / 100; // convert cm to m
      if (weightVal > 0 && heightVal > 0) {
        const bmiVal = calculateBMI(weightVal, heightVal, 'metric');
        updateBmiResults(bmiVal);
      }
    } else if (unit === 'imperial' && weight && (heightFt || heightIn)) {
      const weightVal = parseFloat(weight);
      const heightInches = (parseFloat(heightFt) || 0) * 12 + (parseFloat(heightIn) || 0);
      if (weightVal > 0 && heightInches > 0) {
        const bmiVal = calculateBMI(weightVal, heightInches, 'imperial');
        updateBmiResults(bmiVal);
      }
    } else {
      setBmi(null);
      setWeightCategory("");
    }
  };

  const updateBmiResults = (bmiVal: number) => {
    setBmi(bmiVal);
    
    // Determine weight category based on BMI
    if (bmiVal < 18.5) {
      setWeightCategory("Underweight");
    } else if (bmiVal < 25) {
      setWeightCategory("Normal weight");
    } else if (bmiVal < 30) {
      setWeightCategory("Overweight");
    } else {
      setWeightCategory("Obese");
    }
  };

  const getCategoryColor = (category: string) => {
    switch (category) {
      case "Underweight":
        return "text-blue-500";
      case "Normal weight":
        return "text-green-500";
      case "Overweight":
        return "text-yellow-500";
      case "Obese":
        return "text-red-500";
      default:
        return "";
    }
  };

  const getBmiRangeColor = (bmi: number) => {
    if (bmi < 18.5) return "bg-blue-100";
    if (bmi < 25) return "bg-green-100";
    if (bmi < 30) return "bg-yellow-100";
    return "bg-red-100";
  };

  return (
    <div className="space-y-8">
      <Card>
        <CardContent className="pt-6">
          <Tabs defaultValue="metric" onValueChange={(value) => setUnit(value as 'metric' | 'imperial')}>
            <TabsList className="grid w-full grid-cols-2">
              <TabsTrigger value="metric">Metric (kg/cm)</TabsTrigger>
              <TabsTrigger value="imperial">Imperial (lb/ft-in)</TabsTrigger>
            </TabsList>
            <TabsContent value="metric" className="space-y-4 pt-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="weight-metric">Weight (kg)</Label>
                  <Input
                    id="weight-metric"
                    type="number"
                    placeholder="Enter weight"
                    value={weight}
                    onChange={(e) => setWeight(e.target.value)}
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="height-metric">Height (cm)</Label>
                  <Input
                    id="height-metric"
                    type="number"
                    placeholder="Enter height"
                    value={height}
                    onChange={(e) => setHeight(e.target.value)}
                  />
                </div>
              </div>
            </TabsContent>
            <TabsContent value="imperial" className="space-y-4 pt-4">
              <div className="space-y-2">
                <Label htmlFor="weight-imperial">Weight (lb)</Label>
                <Input
                  id="weight-imperial"
                  type="number"
                  placeholder="Enter weight"
                  value={weight}
                  onChange={(e) => setWeight(e.target.value)}
                />
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="height-ft">Height (ft)</Label>
                  <Input
                    id="height-ft"
                    type="number"
                    placeholder="Feet"
                    value={heightFt}
                    onChange={(e) => setHeightFt(e.target.value)}
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="height-in">Height (in)</Label>
                  <Input
                    id="height-in"
                    type="number"
                    placeholder="Inches"
                    value={heightIn}
                    onChange={(e) => setHeightIn(e.target.value)}
                  />
                </div>
              </div>
            </TabsContent>
          </Tabs>
        </CardContent>
      </Card>

      {bmi !== null && (
        <Card>
          <CardContent className="pt-6">
            <div className="space-y-6">
              <div className="text-center">
                <h3 className="text-lg font-medium mb-2">Your BMI Result</h3>
                <div className="text-4xl font-bold">{bmi.toFixed(1)}</div>
                <div className={`text-lg font-medium mt-2 ${getCategoryColor(weightCategory)}`}>
                  {weightCategory}
                </div>
              </div>
              
              <div className="relative h-6 rounded-full bg-gray-200 overflow-hidden">
                <div className="absolute top-0 left-0 w-full flex text-xs">
                  <div className="flex-1 bg-blue-100 h-6 flex items-center justify-center">
                    Underweight
                  </div>
                  <div className="flex-1 bg-green-100 h-6 flex items-center justify-center">
                    Normal
                  </div>
                  <div className="flex-1 bg-yellow-100 h-6 flex items-center justify-center">
                    Overweight
                  </div>
                  <div className="flex-1 bg-red-100 h-6 flex items-center justify-center">
                    Obese
                  </div>
                </div>
                <div 
                  className="absolute top-0 h-6 w-1 bg-black" 
                  style={{ left: `${Math.min(Math.max(bmi/50 * 100, 0), 100)}%` }}
                ></div>
              </div>

              <div className="grid grid-cols-4 text-center text-sm">
                <div>0</div>
                <div>18.5</div>
                <div>25</div>
                <div>30+</div>
              </div>
              
              <div className="mt-4 text-sm text-muted-foreground">
                <h4 className="font-medium mb-2">BMI Categories:</h4>
                <ul className="list-disc list-inside space-y-1">
                  <li><span className="text-blue-500 font-medium">Underweight:</span> BMI less than 18.5</li>
                  <li><span className="text-green-500 font-medium">Normal weight:</span> BMI 18.5 to 24.9</li>
                  <li><span className="text-yellow-500 font-medium">Overweight:</span> BMI 25 to 29.9</li>
                  <li><span className="text-red-500 font-medium">Obesity:</span> BMI 30 or greater</li>
                </ul>
                <p className="mt-4">
                  BMI is a screening tool, but it does not diagnose body fatness or health. 
                  Athletes may have high BMI due to muscle mass, not fat. 
                  Consult a healthcare provider for a health assessment.
                </p>
              </div>
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
};

export const CalorieCalculator = () => {
  const [weight, setWeight] = useState<string>("70");
  const [height, setHeight] = useState<string>("170");
  const [age, setAge] = useState<string>("30");
  const [gender, setGender] = useState<"male" | "female">("male");
  const [activityLevel, setActivityLevel] = useState<string>("1.2");
  const [unit, setUnit] = useState<'metric' | 'imperial'>('metric');
  const [bmr, setBmr] = useState<number>(0);
  const [maintenance, setMaintenance] = useState<number>(0);
  const [weightLoss, setWeightLoss] = useState<number>(0);
  const [weightGain, setWeightGain] = useState<number>(0);

  const activityOptions = [
    { value: "1.2", label: "Sedentary (little or no exercise)" },
    { value: "1.375", label: "Light activity (light exercise 1-3 days/week)" },
    { value: "1.55", label: "Moderately active (moderate exercise 3-5 days/week)" },
    { value: "1.725", label: "Very active (hard exercise 6-7 days/week)" },
    { value: "1.9", label: "Extremely active (very hard exercise, physical job)" },
  ];

  useEffect(() => {
    calculateCaloriesNeeded();
  }, [weight, height, age, gender, activityLevel, unit]);

  const calculateCaloriesNeeded = () => {
    let weightKg = parseFloat(weight) || 0;
    let heightCm = parseFloat(height) || 0;
    
    if (unit === 'imperial') {
      // Convert pounds to kg and inches to cm
      weightKg = weightKg / 2.20462;
      heightCm = heightCm * 2.54;
    }
    
    const ageYears = parseFloat(age) || 0;
    const activityFactor = parseFloat(activityLevel) || 1.2;

    // Calculate using Mifflin-St Jeor Equation
    let calculatedBmr;
    if (gender === 'male') {
      calculatedBmr = (10 * weightKg) + (6.25 * heightCm) - (5 * ageYears) + 5;
    } else {
      calculatedBmr = (10 * weightKg) + (6.25 * heightCm) - (5 * ageYears) - 161;
    }
    
    const dailyCalories = calculatedBmr * activityFactor;
    
    setBmr(Math.round(calculatedBmr));
    setMaintenance(Math.round(dailyCalories));
    setWeightLoss(Math.round(dailyCalories * 0.8)); // 20% deficit
    setWeightGain(Math.round(dailyCalories * 1.15)); // 15% surplus
  };

  return (
    <div className="space-y-8">
      <Card>
        <CardContent className="pt-6">
          <Tabs defaultValue="metric" onValueChange={(value) => setUnit(value as 'metric' | 'imperial')}>
            <TabsList className="grid w-full grid-cols-2">
              <TabsTrigger value="metric">Metric (kg/cm)</TabsTrigger>
              <TabsTrigger value="imperial">Imperial (lb/in)</TabsTrigger>
            </TabsList>
            
            <div className="space-y-4 pt-4">
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                <TabsContent value="metric" className="space-y-4">
                  <div className="space-y-2">
                    <Label htmlFor="weight-metric">Weight (kg)</Label>
                    <Input
                      id="weight-metric"
                      type="number"
                      value={weight}
                      onChange={(e) => setWeight(e.target.value)}
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="height-metric">Height (cm)</Label>
                    <Input
                      id="height-metric"
                      type="number"
                      value={height}
                      onChange={(e) => setHeight(e.target.value)}
                    />
                  </div>
                </TabsContent>
                
                <TabsContent value="imperial" className="space-y-4">
                  <div className="space-y-2">
                    <Label htmlFor="weight-imperial">Weight (lb)</Label>
                    <Input
                      id="weight-imperial"
                      type="number"
                      value={weight}
                      onChange={(e) => setWeight(e.target.value)}
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="height-imperial">Height (in)</Label>
                    <Input
                      id="height-imperial"
                      type="number"
                      value={height}
                      onChange={(e) => setHeight(e.target.value)}
                    />
                  </div>
                </TabsContent>
                
                <div className="space-y-2">
                  <Label htmlFor="age">Age</Label>
                  <Input
                    id="age"
                    type="number"
                    value={age}
                    onChange={(e) => setAge(e.target.value)}
                  />
                </div>
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="gender">Gender</Label>
                <RadioGroup
                  id="gender"
                  value={gender}
                  onValueChange={(value) => setGender(value as "male" | "female")}
                  className="flex space-x-4"
                >
                  <div className="flex items-center space-x-2">
                    <RadioGroupItem value="male" id="gender-male" />
                    <Label htmlFor="gender-male">Male</Label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <RadioGroupItem value="female" id="gender-female" />
                    <Label htmlFor="gender-female">Female</Label>
                  </div>
                </RadioGroup>
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="activity-level">Activity Level</Label>
                <Select value={activityLevel} onValueChange={setActivityLevel}>
                  <SelectTrigger id="activity-level">
                    <SelectValue placeholder="Select activity level" />
                  </SelectTrigger>
                  <SelectContent>
                    {activityOptions.map((option) => (
                      <SelectItem key={option.value} value={option.value}>
                        {option.label}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>
          </Tabs>
        </CardContent>
      </Card>

      <Card>
        <CardContent className="pt-6">
          <div className="space-y-6">
            <div className="text-center">
              <h3 className="text-lg font-medium mb-2">Your Daily Calorie Needs</h3>
              <div className="text-sm text-muted-foreground mb-4">
                Based on the Mifflin-St Jeor Equation
              </div>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <div className="bg-muted p-4 rounded-md mb-4">
                  <div className="text-sm text-muted-foreground">Basal Metabolic Rate (BMR)</div>
                  <div className="text-2xl font-bold">{bmr} calories/day</div>
                  <div className="text-xs text-muted-foreground mt-1">
                    Minimum calories needed for basic functions at rest
                  </div>
                </div>
                
                <div className="bg-primary/10 p-4 rounded-md">
                  <div className="text-sm">Maintenance Calories</div>
                  <div className="text-2xl font-bold">{maintenance} calories/day</div>
                  <div className="text-xs text-muted-foreground mt-1">
                    Calories needed to maintain current weight
                  </div>
                </div>
              </div>
              
              <div>
                <div className="bg-secondary/10 p-4 rounded-md mb-4">
                  <div className="text-sm">Weight Loss</div>
                  <div className="text-2xl font-bold">{weightLoss} calories/day</div>
                  <div className="text-xs text-muted-foreground mt-1">
                    20% calorie deficit for ~0.5kg/1lb loss per week
                  </div>
                </div>
                
                <div className="bg-accent/10 p-4 rounded-md">
                  <div className="text-sm">Weight Gain</div>
                  <div className="text-2xl font-bold">{weightGain} calories/day</div>
                  <div className="text-xs text-muted-foreground mt-1">
                    15% calorie surplus for muscle building
                  </div>
                </div>
              </div>
            </div>
            
            <div className="text-sm text-muted-foreground mt-4 space-y-2">
              <p>
                The values above are estimates based on the Mifflin-St Jeor equation, which is
                considered one of the most accurate formulas for calculating BMR.
              </p>
              <p>
                Your actual calorie needs may vary based on factors like genetics, body
                composition, and specific activity patterns. Monitor your weight changes over
                time and adjust your calorie intake accordingly.
              </p>
              <p>
                Always consult with a healthcare professional before starting a new diet or
                exercise program.
              </p>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};
