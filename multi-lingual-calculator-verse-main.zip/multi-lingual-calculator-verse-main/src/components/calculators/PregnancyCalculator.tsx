
import { useState } from 'react';
import { Calendar as CalendarIcon } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Label } from '@/components/ui/label';
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover';
import { Calendar } from '@/components/ui/calendar';
import { format, addDays, setDate } from 'date-fns';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';

export const PregnancyDueDateCalculator = () => {
  const [lmpDate, setLmpDate] = useState<Date | undefined>(undefined);
  const [dueDate, setDueDate] = useState<Date | undefined>(undefined);
  const [gestationWeeks, setGestationWeeks] = useState<number | null>(null);

  const calculateDueDate = (date: Date) => {
    // Standard calculation: LMP + 280 days (40 weeks)
    const calculatedDueDate = addDays(date, 280);
    setDueDate(calculatedDueDate);
    
    // Calculate current gestation
    const today = new Date();
    const daysSinceLMP = Math.floor((today.getTime() - date.getTime()) / (1000 * 60 * 60 * 24));
    const weeks = Math.floor(daysSinceLMP / 7);
    setGestationWeeks(weeks >= 0 ? weeks : null);
  };

  const handleDateChange = (date: Date | undefined) => {
    if (date) {
      setLmpDate(date);
      calculateDueDate(date);
    } else {
      setLmpDate(undefined);
      setDueDate(undefined);
      setGestationWeeks(null);
    }
  };

  return (
    <Card className="w-full">
      <CardContent className="pt-6">
        <div className="space-y-6">
          <div className="space-y-2">
            <Label htmlFor="lmp">First day of last menstrual period</Label>
            <Popover>
              <PopoverTrigger asChild>
                <Button
                  variant="outline"
                  className="w-full justify-start text-left font-normal"
                >
                  <CalendarIcon className="mr-2 h-4 w-4" />
                  {lmpDate ? format(lmpDate, 'PPP') : <span>Select date</span>}
                </Button>
              </PopoverTrigger>
              <PopoverContent className="w-auto p-0">
                <Calendar
                  mode="single"
                  selected={lmpDate}
                  onSelect={handleDateChange}
                  initialFocus
                />
              </PopoverContent>
            </Popover>
          </div>

          {dueDate && (
            <div className="space-y-4">
              <div className="bg-muted p-4 rounded-md">
                <h3 className="font-medium text-lg mb-2">Estimated Due Date</h3>
                <p className="text-2xl font-bold text-primary">{format(dueDate, 'MMMM d, yyyy')}</p>
                
                {gestationWeeks !== null && (
                  <div className="mt-4">
                    <h4 className="font-medium">Current Pregnancy Stage</h4>
                    <p className="mt-1">
                      You are approximately <span className="font-medium">{gestationWeeks} weeks</span> pregnant
                      {gestationWeeks < 13 && " (First Trimester)"}
                      {gestationWeeks >= 13 && gestationWeeks < 27 && " (Second Trimester)"}
                      {gestationWeeks >= 27 && " (Third Trimester)"}
                    </p>
                  </div>
                )}
              </div>
              
              <div className="text-sm text-muted-foreground">
                <p>This is an estimate based on a standard 40-week pregnancy calculated from the first day of your last period.</p>
                <p className="mt-2">Only about 5% of babies are born exactly on their due date. Most births occur within a week before or after.</p>
              </div>
            </div>
          )}
        </div>
      </CardContent>
    </Card>
  );
};

export const OvulationCalculator = () => {
  const [lastPeriodDate, setLastPeriodDate] = useState<Date | undefined>(undefined);
  const [cycleLength, setCycleLength] = useState<string>("28");
  const [ovulationDate, setOvulationDate] = useState<Date | undefined>(undefined);
  const [fertileWindow, setFertileWindow] = useState<{ start: Date; end: Date } | null>(null);

  const calculateOvulation = (date: Date, cycle: number) => {
    // Ovulation typically occurs 14 days before the next period
    const daysToAdd = cycle - 14;
    const calculatedOvulationDate = addDays(date, daysToAdd);
    setOvulationDate(calculatedOvulationDate);
    
    // Fertile window is typically 5 days before ovulation plus ovulation day
    const fertileStart = addDays(calculatedOvulationDate, -5);
    setFertileWindow({
      start: fertileStart,
      end: calculatedOvulationDate
    });
  };

  const handleDateChange = (date: Date | undefined) => {
    if (date) {
      setLastPeriodDate(date);
      calculateOvulation(date, parseInt(cycleLength));
    } else {
      setLastPeriodDate(undefined);
      setOvulationDate(undefined);
      setFertileWindow(null);
    }
  };

  const handleCycleLengthChange = (value: string) => {
    setCycleLength(value);
    if (lastPeriodDate) {
      calculateOvulation(lastPeriodDate, parseInt(value));
    }
  };

  const cycleLengthOptions = Array.from({ length: 15 }, (_, i) => (21 + i).toString());

  return (
    <Card className="w-full">
      <CardContent className="pt-6">
        <div className="space-y-6">
          <div className="space-y-2">
            <Label htmlFor="lastPeriod">First day of your last period</Label>
            <Popover>
              <PopoverTrigger asChild>
                <Button
                  variant="outline"
                  className="w-full justify-start text-left font-normal"
                >
                  <CalendarIcon className="mr-2 h-4 w-4" />
                  {lastPeriodDate ? format(lastPeriodDate, 'PPP') : <span>Select date</span>}
                </Button>
              </PopoverTrigger>
              <PopoverContent className="w-auto p-0">
                <Calendar
                  mode="single"
                  selected={lastPeriodDate}
                  onSelect={handleDateChange}
                  initialFocus
                />
              </PopoverContent>
            </Popover>
          </div>

          <div className="space-y-2">
            <Label htmlFor="cycle-length">Average cycle length (days)</Label>
            <Select value={cycleLength} onValueChange={handleCycleLengthChange}>
              <SelectTrigger>
                <SelectValue placeholder="Select cycle length" />
              </SelectTrigger>
              <SelectContent>
                {cycleLengthOptions.map((days) => (
                  <SelectItem key={days} value={days}>{days} days</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          {ovulationDate && fertileWindow && (
            <div className="space-y-4">
              <div className="bg-muted p-4 rounded-md">
                <h3 className="font-medium text-lg mb-2">Your Fertility Window</h3>
                <div className="space-y-2">
                  <div>
                    <span className="font-medium">Estimated Ovulation Date:</span>
                    <p className="text-lg font-bold text-primary">{format(ovulationDate, 'MMMM d, yyyy')}</p>
                  </div>
                  <div>
                    <span className="font-medium">Fertile Window:</span>
                    <p className="text-lg font-bold text-primary">
                      {format(fertileWindow.start, 'MMMM d')} - {format(ovulationDate, 'MMMM d, yyyy')}
                    </p>
                  </div>
                </div>
              </div>
              
              <div className="text-sm text-muted-foreground">
                <p>The fertile window includes the 5 days before ovulation and the day of ovulation itself. These are the days when pregnancy is possible.</p>
                <p className="mt-2">Sperm can survive up to 5 days in the female reproductive tract, while an egg can only be fertilized for about 24 hours after ovulation.</p>
                <p className="mt-2">For the most accurate predictions, track your cycle over several months to identify your average length.</p>
              </div>
            </div>
          )}
        </div>
      </CardContent>
    </Card>
  );
};
