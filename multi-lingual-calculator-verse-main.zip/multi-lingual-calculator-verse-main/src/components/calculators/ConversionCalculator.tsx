
import React, { useState, useEffect } from 'react';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card, CardContent } from '@/components/ui/card';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Button } from '@/components/ui/button';
import { temperatureConversions } from '@/utils/calculatorUtils';
import { Tabs, TabsList, TabsTrigger, TabsContent } from '@/components/ui/tabs';

export const CurrencyConverter = () => {
  const [amount, setAmount] = useState<string>("1");
  const [fromCurrency, setFromCurrency] = useState<string>("USD");
  const [toCurrency, setToCurrency] = useState<string>("EUR");
  const [convertedAmount, setConvertedAmount] = useState<number>(0);
  const [exchangeRate, setExchangeRate] = useState<number>(0);
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [lastUpdated, setLastUpdated] = useState<string>("");

  // Popular currencies
  const popularCurrencies = [
    { code: "USD", name: "US Dollar" },
    { code: "EUR", name: "Euro" },
    { code: "GBP", name: "British Pound" },
    { code: "JPY", name: "Japanese Yen" },
    { code: "CAD", name: "Canadian Dollar" },
    { code: "AUD", name: "Australian Dollar" },
    { code: "CHF", name: "Swiss Franc" },
    { code: "CNY", name: "Chinese Yuan" },
    { code: "INR", name: "Indian Rupee" },
    { code: "MXN", name: "Mexican Peso" }
  ];

  // Mock exchange rates (in a real app, you would fetch these from an API)
  const mockExchangeRates: {[key: string]: number} = {
    "USD_EUR": 0.92,
    "USD_GBP": 0.78,
    "USD_JPY": 149.50,
    "USD_CAD": 1.36,
    "USD_AUD": 1.51,
    "USD_CHF": 0.89,
    "USD_CNY": 7.24,
    "USD_INR": 83.47,
    "USD_MXN": 17.01,
    "EUR_USD": 1.09,
    "EUR_GBP": 0.85,
    "EUR_JPY": 163.13,
    "EUR_CAD": 1.49,
    "EUR_AUD": 1.65,
    "EUR_CHF": 0.97,
    "EUR_CNY": 7.90,
    "EUR_INR": 91.08,
    "EUR_MXN": 18.57,
    "GBP_USD": 1.28,
    "GBP_EUR": 1.18,
    "GBP_JPY": 191.30,
    "GBP_CAD": 1.74,
    "GBP_AUD": 1.94,
    "GBP_CHF": 1.14,
    "GBP_CNY": 9.27,
    "GBP_INR": 107.00,
    "GBP_MXN": 21.77
  };

  // Function to get exchange rate (mock implementation)
  const getExchangeRate = (from: string, to: string): number => {
    // For simplicity, we'll use our mock data
    if (from === to) return 1;
    
    const rateKey = `${from}_${to}`;
    if (mockExchangeRates[rateKey]) {
      return mockExchangeRates[rateKey];
    }
    
    // If direct rate not found, try to calculate via USD
    const fromToUSD = from === "USD" ? 1 : mockExchangeRates[`${from}_USD`] || 1 / (mockExchangeRates[`USD_${from}`] || 1);
    const usdToTo = to === "USD" ? 1 : mockExchangeRates[`USD_${to}`] || 1 / (mockExchangeRates[`${to}_USD`] || 1);
    
    return fromToUSD * usdToTo;
  };

  // Convert currency when inputs change
  useEffect(() => {
    convertCurrency();
  }, [amount, fromCurrency, toCurrency]);

  const convertCurrency = () => {
    setIsLoading(true);
    
    // Simulate API call
    setTimeout(() => {
      const rate = getExchangeRate(fromCurrency, toCurrency);
      setExchangeRate(rate);
      
      const result = (parseFloat(amount) || 0) * rate;
      setConvertedAmount(result);
      
      const now = new Date();
      setLastUpdated(now.toLocaleString());
      setIsLoading(false);
    }, 500);
  };

  const swapCurrencies = () => {
    setFromCurrency(toCurrency);
    setToCurrency(fromCurrency);
  };

  return (
    <Card className="w-full">
      <CardContent className="pt-6">
        <div className="space-y-6">
          <div className="space-y-2">
            <Label htmlFor="amount">Amount</Label>
            <Input
              id="amount"
              type="number"
              value={amount}
              onChange={(e) => setAmount(e.target.value)}
              className="text-lg"
            />
          </div>

          <div className="grid grid-cols-[1fr,auto,1fr] gap-2 items-center">
            <div className="space-y-2">
              <Label htmlFor="from-currency">From</Label>
              <Select value={fromCurrency} onValueChange={setFromCurrency}>
                <SelectTrigger id="from-currency">
                  <SelectValue placeholder="Select currency" />
                </SelectTrigger>
                <SelectContent>
                  {popularCurrencies.map((currency) => (
                    <SelectItem key={currency.code} value={currency.code}>
                      {currency.code} - {currency.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <Button 
              variant="outline" 
              className="mt-6" 
              onClick={swapCurrencies}
              aria-label="Swap currencies"
            >
              ↔️
            </Button>

            <div className="space-y-2">
              <Label htmlFor="to-currency">To</Label>
              <Select value={toCurrency} onValueChange={setToCurrency}>
                <SelectTrigger id="to-currency">
                  <SelectValue placeholder="Select currency" />
                </SelectTrigger>
                <SelectContent>
                  {popularCurrencies.map((currency) => (
                    <SelectItem key={currency.code} value={currency.code}>
                      {currency.code} - {currency.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>

          <div className="bg-muted p-4 rounded-md">
            <div className="text-sm text-muted-foreground mb-1">Result</div>
            <div className="text-2xl font-bold">
              {isLoading ? (
                "Converting..."
              ) : (
                <>
                  {parseFloat(amount) || 0} {fromCurrency} = {convertedAmount.toFixed(2)} {toCurrency}
                </>
              )}
            </div>
            <div className="text-sm text-muted-foreground mt-2">
              <div>Exchange Rate: 1 {fromCurrency} = {exchangeRate.toFixed(4)} {toCurrency}</div>
              {lastUpdated && <div className="mt-1">Last updated: {lastUpdated}</div>}
            </div>
          </div>

          <div className="text-sm text-muted-foreground">
            <p>Note: Exchange rates are for informational purposes only. Actual rates used for transactions may vary.</p>
          </div>
        </div>
      </CardContent>
    </Card>
  );
};

export const PercentageCalculator = () => {
  const [calculationType, setCalculationType] = useState<string>("percentage-of");
  const [value1, setValue1] = useState<string>("20");
  const [value2, setValue2] = useState<string>("100");
  const [result, setResult] = useState<number>(0);
  const [resultText, setResultText] = useState<string>("");
  
  useEffect(() => {
    calculateResult();
  }, [calculationType, value1, value2]);
  
  const calculateResult = () => {
    const val1 = parseFloat(value1) || 0;
    const val2 = parseFloat(value2) || 0;
    
    switch(calculationType) {
      case "percentage-of":
        // Calculate X% of Y (e.g., 20% of 100 = 20)
        const percentageOf = (val1 * val2) / 100;
        setResult(percentageOf);
        setResultText(`${val1}% of ${val2} = ${percentageOf}`);
        break;
        
      case "percentage":
        // Calculate what percentage is X of Y (e.g., 20 is 20% of 100)
        const percentage = val2 !== 0 ? (val1 / val2) * 100 : 0;
        setResult(percentage);
        setResultText(`${val1} is ${percentage.toFixed(2)}% of ${val2}`);
        break;
        
      case "increase":
        // Calculate percentage increase/decrease (e.g., 120 from 100 is 20% increase)
        if (val2 !== 0) {
          const percentChange = ((val1 - val2) / Math.abs(val2)) * 100;
          setResult(percentChange);
          if (percentChange > 0) {
            setResultText(`Increase from ${val2} to ${val1} is ${percentChange.toFixed(2)}%`);
          } else if (percentChange < 0) {
            setResultText(`Decrease from ${val2} to ${val1} is ${Math.abs(percentChange).toFixed(2)}%`);
          } else {
            setResultText(`No change from ${val2} to ${val1}`);
          }
        }
        break;
    }
  };

  return (
    <Card className="w-full">
      <CardContent className="pt-6">
        <div className="space-y-6">
          <div className="space-y-2">
            <Label htmlFor="calculation-type">Calculation Type</Label>
            <Select value={calculationType} onValueChange={setCalculationType}>
              <SelectTrigger id="calculation-type">
                <SelectValue placeholder="Select calculation type" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="percentage-of">X% of Y = ?</SelectItem>
                <SelectItem value="percentage">X is what % of Y?</SelectItem>
                <SelectItem value="increase">Percentage increase/decrease</SelectItem>
              </SelectContent>
            </Select>
          </div>
          
          <div className="grid grid-cols-1 gap-4">
            {calculationType === "percentage-of" && (
              <>
                <div className="space-y-2">
                  <Label htmlFor="percentage">Percentage (%)</Label>
                  <Input
                    id="percentage"
                    type="number"
                    value={value1}
                    onChange={(e) => setValue1(e.target.value)}
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="of-value">Of Value</Label>
                  <Input
                    id="of-value"
                    type="number"
                    value={value2}
                    onChange={(e) => setValue2(e.target.value)}
                  />
                </div>
              </>
            )}
            
            {calculationType === "percentage" && (
              <>
                <div className="space-y-2">
                  <Label htmlFor="part-value">Value X</Label>
                  <Input
                    id="part-value"
                    type="number"
                    value={value1}
                    onChange={(e) => setValue1(e.target.value)}
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="whole-value">Value Y (total)</Label>
                  <Input
                    id="whole-value"
                    type="number"
                    value={value2}
                    onChange={(e) => setValue2(e.target.value)}
                  />
                </div>
              </>
            )}
            
            {calculationType === "increase" && (
              <>
                <div className="space-y-2">
                  <Label htmlFor="new-value">New Value</Label>
                  <Input
                    id="new-value"
                    type="number"
                    value={value1}
                    onChange={(e) => setValue1(e.target.value)}
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="original-value">Original Value</Label>
                  <Input
                    id="original-value"
                    type="number"
                    value={value2}
                    onChange={(e) => setValue2(e.target.value)}
                  />
                </div>
              </>
            )}
          </div>
          
          <div className="bg-muted p-4 rounded-md">
            <div className="text-sm text-muted-foreground mb-1">Result</div>
            <div className="text-2xl font-bold">
              {resultText}
            </div>
          </div>
          
          <div className="text-sm text-muted-foreground space-y-2">
            <p>Common percentage calculations:</p>
            <ul className="list-disc list-inside">
              <li>Finding a percentage of a number: multiply the number by the percentage and divide by 100.</li>
              <li>Finding what percentage one number is of another: divide the first number by the second and multiply by 100.</li>
              <li>Finding percentage change: subtract the old value from the new value, divide by the old value, and multiply by 100.</li>
            </ul>
          </div>
        </div>
      </CardContent>
    </Card>
  );
};

export const TemperatureConverter = () => {
  const [inputValue, setInputValue] = useState<string>("0");
  const [inputUnit, setInputUnit] = useState<string>("celsius");
  const [outputValue, setOutputValue] = useState<string>("32");
  const [outputUnit, setOutputUnit] = useState<string>("fahrenheit");

  useEffect(() => {
    convertTemperature();
  }, [inputValue, inputUnit, outputUnit]);

  const convertTemperature = () => {
    const value = parseFloat(inputValue) || 0;
    let result;
    
    // First convert to Celsius if not already in Celsius
    let celsius;
    if (inputUnit === "celsius") {
      celsius = value;
    } else {
      celsius = temperatureConversions.fahrenheitToCelsius(value);
    }
    
    // Then convert from Celsius to target unit
    if (outputUnit === "celsius") {
      result = celsius;
    } else {
      result = temperatureConversions.celsiusToFahrenheit(celsius);
    }
    
    setOutputValue(result.toFixed(2));
  };

  const swapUnits = () => {
    const tempUnit = inputUnit;
    const tempValue = inputValue;
    
    setInputUnit(outputUnit);
    setInputValue(outputValue);
    setOutputUnit(tempUnit);
    setOutputValue(tempValue);
  };

  return (
    <Card className="w-full">
      <CardContent className="pt-6">
        <div className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            <div className="space-y-4">
              <Label htmlFor="input-value">Input Value</Label>
              <div className="flex space-x-2">
                <Input
                  id="input-value"
                  type="number"
                  value={inputValue}
                  onChange={(e) => setInputValue(e.target.value)}
                  className="text-lg"
                />
                <Select value={inputUnit} onValueChange={setInputUnit}>
                  <SelectTrigger className="w-[120px]">
                    <SelectValue placeholder="Unit" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="celsius">°C</SelectItem>
                    <SelectItem value="fahrenheit">°F</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
            
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <Label htmlFor="output-value">Output Value</Label>
                <Button
                  variant="outline"
                  size="icon"
                  onClick={swapUnits}
                  aria-label="Swap units"
                >
                  ↔️
                </Button>
              </div>
              <div className="flex space-x-2">
                <Input
                  id="output-value"
                  type="text"
                  value={outputValue}
                  readOnly
                  className="text-lg bg-muted"
                />
                <Select value={outputUnit} onValueChange={setOutputUnit}>
                  <SelectTrigger className="w-[120px]">
                    <SelectValue placeholder="Unit" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="celsius">°C</SelectItem>
                    <SelectItem value="fahrenheit">°F</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
          </div>
          
          <div className="bg-muted p-4 rounded-md">
            <h3 className="font-medium text-lg mb-2">Temperature Reference Points</h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <h4 className="font-medium">Celsius (°C)</h4>
                <ul className="space-y-1 text-sm">
                  <li>Water freezing point: 0°C</li>
                  <li>Room temperature: ~20-22°C</li>
                  <li>Body temperature: ~37°C</li>
                  <li>Water boiling point: 100°C</li>
                </ul>
              </div>
              <div>
                <h4 className="font-medium">Fahrenheit (°F)</h4>
                <ul className="space-y-1 text-sm">
                  <li>Water freezing point: 32°F</li>
                  <li>Room temperature: ~68-72°F</li>
                  <li>Body temperature: ~98.6°F</li>
                  <li>Water boiling point: 212°F</li>
                </ul>
              </div>
            </div>
          </div>
          
          <div className="text-sm text-muted-foreground">
            <p className="font-medium">Conversion Formulas:</p>
            <ul className="list-disc list-inside space-y-1">
              <li>Fahrenheit to Celsius: (°F - 32) × 5/9</li>
              <li>Celsius to Fahrenheit: (°C × 9/5) + 32</li>
            </ul>
          </div>
        </div>
      </CardContent>
    </Card>
  );
};
