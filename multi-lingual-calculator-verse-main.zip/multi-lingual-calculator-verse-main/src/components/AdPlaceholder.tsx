
const AdPlaceholder = () => {
  return (
    <div className="w-full my-8 p-4 bg-muted/50 border rounded-md text-center">
      <p className="text-muted-foreground">
        Ad Space - Place Google AdSense here
      </p>
    </div>
  );
};

export default AdPlaceholder;
