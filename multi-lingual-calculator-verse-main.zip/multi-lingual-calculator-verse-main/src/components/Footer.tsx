
import { Link } from 'react-router-dom';

const Footer = () => {
  const year = new Date().getFullYear();
  
  return (
    <footer className="bg-background border-t py-6">
      <div className="container mx-auto px-4">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          <div>
            <h3 className="font-bold text-lg mb-4">
              Ultimate Calculator
            </h3>
            <p className="text-muted-foreground">
              Use various calculators and converters in one place.
            </p>
          </div>
          
          <div>
            <h3 className="font-bold text-lg mb-4">Categories</h3>
            <ul className="space-y-2">
              <li>
                <Link to="/category/finance" className="text-muted-foreground hover:text-primary">
                  Finance
                </Link>
              </li>
              <li>
                <Link to="/category/health" className="text-muted-foreground hover:text-primary">
                  Health
                </Link>
              </li>
              <li>
                <Link to="/category/conversion" className="text-muted-foreground hover:text-primary">
                  Unit Conversion
                </Link>
              </li>
            </ul>
          </div>
          
          <div>
            <h3 className="font-bold text-lg mb-4">Information</h3>
            <p className="text-muted-foreground">
              © {year} Ultimate Calculator
            </p>
            <p className="text-muted-foreground">
              All Rights Reserved
            </p>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
