
import React from 'react';
import { useLanguage } from '@/contexts/LanguageContext';
import { Link } from 'react-router-dom';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { calculatorCategories } from '@/data/calculatorData';
import AdPlaceholder from './AdPlaceholder';

const HomePage = () => {
  const { t } = useLanguage();

  return (
    <div className="container mx-auto px-4 py-8">
      <section className="text-center mb-12">
        <h1 className="text-4xl font-bold mb-4">
          {t('끝판왕 온라인 계산기', 'Ultimate Online Calculator')}
        </h1>
        <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
          {t(
            '금융·부동산·건강·공학·생활·시간·교육 등 모든 분야의 계산기와 환산기를 한 웹사이트에서 제공합니다.',
            'Providing calculators and converters for all fields including finance, real estate, health, engineering, lifestyle, time, and education in one website.'
          )}
        </p>
      </section>

      <AdPlaceholder />

      {calculatorCategories.map((category) => (
        <section key={category.id} className="calculator-section">
          <h2 className="text-3xl font-bold mb-6">
            {t(category.titleKo, category.titleEn)}
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {category.calculators.map((calculator) => (
              <Link key={calculator.id} to={calculator.path}>
                <Card className="h-full hover:shadow-md transition-shadow">
                  <CardHeader>
                    <CardTitle>{t(calculator.titleKo, calculator.titleEn)}</CardTitle>
                    <CardDescription>
                      {t(calculator.descriptionKo, calculator.descriptionEn)}
                    </CardDescription>
                  </CardHeader>
                </Card>
              </Link>
            ))}
          </div>
        </section>
      ))}

      <AdPlaceholder />
    </div>
  );
};

export default HomePage;
