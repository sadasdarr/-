
import { useState, useRef, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { Search } from 'lucide-react';
import { getAllCalculators } from '@/data/calculatorData';
import { Input } from '@/components/ui/input';
import { Command, CommandEmpty, CommandGroup, CommandInput, CommandItem, CommandList } from '@/components/ui/command';
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover';

const SearchBar = () => {
  const [open, setOpen] = useState(false);
  const [search, setSearch] = useState('');
  const navigate = useNavigate();
  const allCalculators = getAllCalculators();
  const inputRef = useRef<HTMLInputElement>(null);

  // Handle keyboard shortcuts
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if ((e.metaKey || e.ctrlKey) && e.key === 'k') {
        e.preventDefault();
        setOpen((prev) => !prev);
      }
    };

    document.addEventListener('keydown', handleKeyDown);
    return () => document.removeEventListener('keydown', handleKeyDown);
  }, []);

  const filteredCalculators = allCalculators.filter((calculator) => {
    const searchTerm = search.toLowerCase();
    return (
      calculator.title.toLowerCase().includes(searchTerm) ||
      calculator.description.toLowerCase().includes(searchTerm) ||
      calculator.category.toLowerCase().includes(searchTerm)
    );
  });

  const handleSelect = (path: string) => {
    navigate(path);
    setOpen(false);
  };

  return (
    <Popover open={open} onOpenChange={setOpen}>
      <PopoverTrigger asChild>
        <div className="relative w-full max-w-sm">
          <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
          <Input
            ref={inputRef}
            onClick={() => setOpen(true)}
            placeholder="Search calculators... (Ctrl+K)"
            className="pl-10 pr-4"
          />
        </div>
      </PopoverTrigger>
      <PopoverContent className="p-0 w-[350px] md:w-[500px]" align="start">
        <Command>
          <CommandInput 
            placeholder="Search by calculator name, description, or category..." 
            value={search}
            onValueChange={setSearch}
          />
          <CommandList>
            <CommandEmpty>No results found.</CommandEmpty>
            <CommandGroup heading="Calculators">
              {filteredCalculators.map((calculator) => (
                <CommandItem
                  key={calculator.id}
                  value={calculator.title}
                  onSelect={() => handleSelect(calculator.path)}
                >
                  <div className="flex flex-col">
                    <span className="font-medium">
                      {calculator.title.split('–')[0].trim()}
                    </span>
                    <span className="text-xs text-muted-foreground">
                      {calculator.description}
                    </span>
                  </div>
                </CommandItem>
              ))}
            </CommandGroup>
          </CommandList>
        </Command>
      </PopoverContent>
    </Popover>
  );
};

export default SearchBar;
