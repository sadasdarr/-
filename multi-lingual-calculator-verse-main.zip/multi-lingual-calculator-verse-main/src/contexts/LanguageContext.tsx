
import React, { createContext, useState, useContext, ReactNode, useEffect } from 'react';

type Language = 'ko' | 'en';

interface LanguageContextType {
  language: Language;
  setLanguage: (language: Language) => void;
  t: (ko: string, en: string) => string;
}

const LanguageContext = createContext<LanguageContextType | undefined>(undefined);

export const LanguageProvider = ({ children }: { children: ReactNode }) => {
  const [language, setLanguage] = useState<Language>(() => {
    // Try to get language from localStorage first
    const savedLanguage = localStorage.getItem('preferredLanguage');
    // Then check browser language preference
    const browserLang = navigator.language.startsWith('ko') ? 'ko' : 'en';
    return (savedLanguage === 'ko' || savedLanguage === 'en') ? savedLanguage : browserLang;
  });

  // Save language preference to localStorage whenever it changes
  useEffect(() => {
    localStorage.setItem('preferredLanguage', language);
    // Update html lang attribute for SEO
    document.documentElement.lang = language;
    
    // Add hreflang link tags for SEO
    const existingLink = document.querySelector('link[rel="alternate"][hreflang]');
    if (!existingLink) {
      const koLink = document.createElement('link');
      koLink.rel = 'alternate';
      koLink.hreflang = 'ko';
      koLink.href = window.location.origin + window.location.pathname;
      
      const enLink = document.createElement('link');
      enLink.rel = 'alternate';
      enLink.hreflang = 'en';
      enLink.href = window.location.origin + window.location.pathname;
      
      document.head.appendChild(koLink);
      document.head.appendChild(enLink);
    }
  }, [language]);

  const t = (ko: string, en: string): string => {
    return language === 'ko' ? ko : en;
  };

  return (
    <LanguageContext.Provider value={{ language, setLanguage, t }}>
      {children}
    </LanguageContext.Provider>
  );
};

export const useLanguage = (): LanguageContextType => {
  const context = useContext(LanguageContext);
  if (context === undefined) {
    throw new Error('useLanguage must be used within a LanguageProvider');
  }
  return context;
};
