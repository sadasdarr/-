
import { useState, useEffect } from 'react';
import { useParams } from 'react-router-dom';
import Header from '@/components/Header';
import Footer from '@/components/Footer';
import HomePage from '@/components/HomePage';
import { calculatorCategories } from '@/data/calculatorData';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Link } from 'react-router-dom';
import AdPlaceholder from '@/components/AdPlaceholder';

const Index = () => {
  const { categoryId } = useParams<{ categoryId?: string }>();
  const [title, setTitle] = useState<string>('Ultimate Online Calculator');
  
  useEffect(() => {
    if (categoryId) {
      const category = calculatorCategories.find(c => c.id === categoryId);
      if (category) {
        document.title = `${category.title} Calculators - Ultimate Online Calculator`;
        setTitle(`${category.title} Calculators`);
      }
    } else {
      document.title = 'Ultimate Online Calculator';
      setTitle('Ultimate Online Calculator');
    }
  }, [categoryId]);

  return (
    <div className="flex flex-col min-h-screen">
      <Header />
      
      <main className="flex-grow">
        {categoryId ? (
          <CategoryPage categoryId={categoryId} title={title} />
        ) : (
          <HomePage />
        )}
      </main>
      
      <Footer />
    </div>
  );
};

interface CategoryPageProps {
  categoryId: string;
  title: string;
}

const CategoryPage = ({ categoryId, title }: CategoryPageProps) => {
  const category = calculatorCategories.find(c => c.id === categoryId);
  
  if (!category) {
    return (
      <div className="container mx-auto px-4 py-8">
        <h1 className="text-3xl font-bold mb-4">Category not found</h1>
      </div>
    );
  }
  
  return (
    <div className="container mx-auto px-4 py-8">
      <h1 className="text-3xl font-bold mb-4">{title}</h1>
      
      <div className="mb-6">
        <p className="text-lg text-muted-foreground">
          Explore various calculators and converters related to {category.title}.
        </p>
      </div>
      
      <AdPlaceholder />
      
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 my-8">
        {category.calculators.map((calculator) => (
          <Link key={calculator.id} to={calculator.path}>
            <Card className="h-full hover:shadow-md transition-shadow">
              <CardHeader>
                <CardTitle>{calculator.title.split('–')[0].trim()}</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-muted-foreground">
                  {calculator.description}
                </p>
              </CardContent>
            </Card>
          </Link>
        ))}
      </div>
      
      <AdPlaceholder />
    </div>
  );
};

export default Index;
