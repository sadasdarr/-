
import { useEffect } from 'react';
import { useParams, useLocation } from 'react-router-dom';
import { getCalculatorById, getCalculatorByPath } from '@/data/calculatorData';
import Header from '@/components/Header';
import Footer from '@/components/Footer';
import AdPlaceholder from '@/components/AdPlaceholder';
import { BMICalculator, CalorieCalculator } from '@/components/calculators/HealthCalculator';
import { MortgageCalculator, AutoLoanCalculator, CompoundInterestCalculator } from '@/components/calculators/FinanceCalculator';
import { CurrencyConverter, TemperatureConverter, PercentageCalculator } from '@/components/calculators/ConversionCalculator';
import { PregnancyDueDateCalculator, OvulationCalculator } from '@/components/calculators/PregnancyCalculator';

interface CalculatorComponentMap {
  [key: string]: React.ComponentType;
}

const calculatorComponents: CalculatorComponentMap = {
  'bmi': BMICalculator,
  'calories': CalorieCalculator,
  'mortgage': MortgageCalculator,
  'auto-loan': AutoLoanCalculator,
  'compound-interest': CompoundInterestCalculator,
  'currency': CurrencyConverter,
  'percentage': PercentageCalculator,
  'temperature': TemperatureConverter,
  'pregnancy-due-date': PregnancyDueDateCalculator,
  'ovulation': OvulationCalculator,
};

const CalculatorPage = () => {
  const { id } = useParams<{ id: string }>();
  const location = useLocation();
  
  const calculator = id ? getCalculatorById(id) : getCalculatorByPath(location.pathname);
  
  useEffect(() => {
    if (calculator) {
      document.title = calculator.title;
      
      // Update meta description
      const metaDescription = document.querySelector('meta[name="description"]');
      if (metaDescription) {
        metaDescription.setAttribute('content', calculator.metaDescription);
      }
    }
  }, [calculator]);

  if (!calculator) {
    return (
      <div>
        <Header />
        <div className="container mx-auto px-4 py-8 text-center">
          <h1 className="text-3xl font-bold mb-4">Calculator not found</h1>
        </div>
        <Footer />
      </div>
    );
  }

  const CalculatorComponent = calculatorComponents[calculator.id];

  return (
    <div>
      <Header />
      <div className="container mx-auto px-4 py-8">
        <h1 className="text-3xl font-bold mb-4">{calculator.title}</h1>
        
        <div className="mb-8">
          <p className="text-lg text-muted-foreground">{calculator.description}</p>
        </div>

        <AdPlaceholder />
        
        {CalculatorComponent && <CalculatorComponent />}
        
        <div className="mt-8 prose max-w-none">
          <h2 className="text-2xl font-bold mb-4">Detailed Information</h2>
          <p className="whitespace-pre-line">{calculator.longDescription}</p>
        </div>
        
        <AdPlaceholder />
      </div>
      <Footer />
    </div>
  );
};

export default CalculatorPage;
