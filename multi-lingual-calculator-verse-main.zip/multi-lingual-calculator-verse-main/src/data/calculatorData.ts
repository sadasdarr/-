
export interface CalculatorCategory {
  id: string;
  title: string;
  calculators: Calculator[];
}

export interface Calculator {
  id: string;
  path: string;
  title: string;
  description: string;
  metaDescription: string;
  longDescription: string;
  category: string;
}

export const calculatorCategories: CalculatorCategory[] = [
  {
    id: 'health',
    title: 'Health',
    calculators: [
      {
        id: 'bmi',
        path: '/bmi-calculator',
        title: 'BMI Calculator – Calculate Body Mass Index Online',
        description: 'Enter your weight and height to calculate your Body Mass Index (BMI) and see if you are underweight, normal, overweight, or obese.',
        metaDescription: 'Enter your weight and height to calculate your Body Mass Index (BMI) and see if you are underweight, normal, overweight, or obese.',
        longDescription: 'The Body Mass Index (BMI) calculator provides a simple way to assess your body weight relative to your height. BMI is widely used as a preliminary screening tool for potential weight issues. A BMI below 18.5 is considered underweight, 18.5-24.9 is normal weight, 25-29.9 is overweight, and 30 or above is obese. While BMI is useful for most adults 20 years and older, it does have limitations: it may overestimate body fat in athletes with high muscle mass and underestimate it in older persons who have lost muscle. This calculator allows you to input your measurements in either metric (kg/cm) or imperial (lbs/ft/in) units. Remember that BMI is just one indicator of health and should be considered alongside other factors such as waist circumference, blood pressure, cholesterol levels, and overall fitness.',
        category: 'health'
      },
      {
        id: 'calories',
        path: '/calorie-calculator',
        title: 'Calorie Calculator – Daily Caloric Needs & BMR',
        description: 'Find out how many calories you need per day. This calorie calculator uses your age, gender, weight, height, and activity level to estimate your daily caloric requirements and BMR.',
        metaDescription: 'Find out how many calories you need per day. This calorie calculator uses your age, gender, weight, height, and activity level to estimate your daily caloric requirements and BMR.',
        longDescription: 'The Calorie Calculator estimates your daily calorie needs using the Mifflin-St Jeor equation, which is considered one of the most accurate methods available. Your Basal Metabolic Rate (BMR) represents the minimum calories your body needs at rest to maintain basic functions like breathing and circulation. To determine your total daily calorie needs, the calculator multiplies your BMR by an activity factor based on your lifestyle. The results include maintenance calories (to maintain current weight) and adjusted values for weight loss or gain. This information can help you establish realistic nutrition goals whether you\'re looking to lose weight, gain muscle, or maintain your current physique. Remember that while calorie counting is valuable, the quality of food choices (nutrient density, macronutrient balance) is equally important for overall health.',
        category: 'health'
      },
      {
        id: 'pregnancy-due-date',
        path: '/pregnancy-due-date-calculator',
        title: 'Pregnancy Due Date Calculator – Estimate Your Baby\'s Arrival',
        description: 'Calculate your estimated due date. Enter the first day of your last menstrual period to find out when your baby is likely to be born (approximately 40 weeks from LMP).',
        metaDescription: 'Calculate your estimated due date. Enter the first day of your last menstrual period to find out when your baby is likely to be born (approximately 40 weeks from LMP).',
        longDescription: 'The Pregnancy Due Date Calculator provides an estimate of when your baby is likely to arrive based on the first day of your last menstrual period (LMP). The standard calculation adds 280 days (40 weeks) to your LMP, which is the typical length of pregnancy. This method is based on Naegele\'s rule and is used by most healthcare providers. It\'s important to note that only about 5% of women deliver exactly on their due date—most births occur within a week before or after. The calculator also provides information about your current gestational age and the trimesters of your pregnancy. While this calculator offers a good estimate, factors like irregular menstrual cycles or variations in ovulation timing can affect accuracy. Your healthcare provider may adjust your due date based on ultrasound measurements during your prenatal care.',
        category: 'health'
      },
      {
        id: 'ovulation',
        path: '/ovulation-calculator',
        title: 'Ovulation Calculator – Find Your Most Fertile Days',
        description: 'Predict your next ovulation date and fertile window. Enter the start of your last period and your average cycle length to calculate when you\'re most likely to ovulate and maximize chances of conception.',
        metaDescription: 'Predict your next ovulation date and fertile window. Enter the start of your last period and your average cycle length to calculate when you\'re most likely to ovulate and maximize chances of conception.',
        longDescription: 'The Ovulation Calculator helps predict your most fertile days by estimating when you\'re likely to ovulate based on your menstrual cycle information. Ovulation typically occurs about 14 days before the start of your next period, though this can vary. The calculator identifies your fertile window—the days when pregnancy is possible—which includes the 5 days before ovulation and the day of ovulation itself. Sperm can survive in the female reproductive tract for up to 5 days, while an egg remains viable for about 24 hours after ovulation. Understanding your fertile window can help if you\'re trying to conceive or practicing natural family planning. For most accurate results, track your cycles over several months to identify your average cycle length. Note that stress, illness, and lifestyle changes can affect ovulation timing, and this calculator provides estimates rather than exact predictions.',
        category: 'health'
      }
    ]
  },
  {
    id: 'finance',
    title: 'Finance',
    calculators: [
      {
        id: 'mortgage',
        path: '/mortgage-calculator',
        title: 'Mortgage Calculator – Home Loan Payment Estimate',
        description: 'Calculate your monthly mortgage payment. Adjust loan amount, interest rate, and term to compute your house payment and view an amortization schedule.',
        metaDescription: 'Calculate your monthly mortgage payment. Adjust loan amount, interest rate, and term to compute your house payment and view an amortization schedule.',
        longDescription: 'The Mortgage Calculator helps you estimate your monthly home loan payments based on the loan amount, interest rate, and term. It uses the standard amortization formula to calculate how much you\'ll pay each month toward principal and interest. The calculator also generates an amortization schedule showing how your loan balance decreases over time and how the proportion of your payment going toward principal increases while the interest portion decreases. Additional options allow you to include property taxes, homeowners insurance, and PMI (Private Mortgage Insurance) for a more complete monthly payment estimate. This tool is valuable for prospective homebuyers to understand their potential housing costs and for current homeowners to explore refinancing options. Remember that while this calculator provides good estimates, actual loan terms may vary based on your credit score, lender requirements, and other factors.',
        category: 'finance'
      },
      {
        id: 'auto-loan',
        path: '/auto-loan-calculator',
        title: 'Auto Loan Calculator – Car Payment Calculator',
        description: 'Determine your monthly car loan payment. Enter the loan amount, interest rate, and term to calculate your auto loan payments and total interest paid.',
        metaDescription: 'Determine your monthly car loan payment. Enter the loan amount, interest rate, and term to calculate your auto loan payments and total interest paid.',
        longDescription: 'The Auto Loan Calculator helps you estimate your monthly car payments based on the loan amount, interest rate, and loan term. Using the standard amortization formula, it calculates how your monthly payment will be distributed between principal and interest over the life of the loan. The calculator also determines the total cost of the loan including interest, allowing you to see how much your vehicle truly costs beyond the purchase price. Optional inputs for down payment and trade-in value help provide a more accurate picture of your financing needs. This tool is useful when shopping for a new or used vehicle to understand how different loan terms affect your budget and to compare offers from different lenders. Remember that actual loan terms may vary based on your credit score, the age of the vehicle, and lender policies.',
        category: 'finance'
      },
      {
        id: 'compound-interest',
        path: '/compound-interest-calculator',
        title: 'Compound Interest Calculator – Investment Growth Over Time',
        description: 'Calculate the future value of an investment with compound interest. Enter principal, interest rate, time period, and compounding frequency to see how your money grows.',
        metaDescription: 'Calculate the future value of an investment with compound interest. Enter principal, interest rate, time period, and compounding frequency to see how your money grows.',
        longDescription: 'The Compound Interest Calculator demonstrates the powerful concept of compound interest—often called the "eighth wonder of the world." It calculates how your investments grow when interest is added to the principal, so that interest also earns interest over time. The calculator uses the formula A = P(1 + r/n)^(nt), where P is the principal, r is the annual interest rate, n is the number of compounding periods per year, and t is the time in years. You can see how different compounding frequencies (daily, monthly, quarterly, or annually) affect your returns. The results include the future value of your investment and the total interest earned. This tool is valuable for retirement planning, education savings, or any long-term financial goal. It illustrates the benefit of starting to invest early and the impact of even small increases in interest rates over long periods.',
        category: 'finance'
      }
    ]
  },
  {
    id: 'conversion',
    title: 'Conversion',
    calculators: [
      {
        id: 'currency',
        path: '/currency-converter',
        title: 'Currency Converter – Real-Time Currency Exchange Calculator',
        description: 'Convert currencies instantly with our online currency converter. Choose your currencies and enter an amount to see the conversion at the latest exchange rate.',
        metaDescription: 'Convert currencies instantly with our online currency converter. Choose your currencies and enter an amount to see the conversion at the latest exchange rate.',
        longDescription: 'The Currency Converter allows you to convert between different national currencies using up-to-date exchange rates. This tool is particularly useful for travelers planning trips abroad, businesses engaged in international trade, or investors monitoring foreign investments. The converter performs a simple multiplication of the amount by the current exchange rate to provide the converted value. While we strive to provide the most current rates available, please note that actual exchange rates used by banks and services may include additional fees and may differ slightly from the rates displayed. Popular conversions include major currencies such as USD (US Dollar), EUR (Euro), GBP (British Pound), JPY (Japanese Yen), CAD (Canadian Dollar), and AUD (Australian Dollar), but many other currencies are also available.',
        category: 'conversion'
      },
      {
        id: 'percentage',
        path: '/percentage-calculator',
        title: 'Percentage Calculator – Calculate Percent & Percent Change',
        description: 'Easily calculate percentages: find X% of Y, determine what percentage one number is of another, or calculate percent increase/decrease between two numbers.',
        metaDescription: 'Easily calculate percentages: find X% of Y, determine what percentage one number is of another, or calculate percent increase/decrease between two numbers.',
        longDescription: 'The Percentage Calculator is a versatile tool that performs three common percentage calculations: finding a percentage of a number (e.g., what is 15% of 200?), calculating what percentage one number is of another (e.g., 30 is what percentage of 120?), and determining the percentage increase or decrease between two numbers (e.g., the change from 80 to 100 is a 25% increase). Understanding percentages is essential for many everyday situations, from calculating tips and discounts while shopping to analyzing business growth rates or evaluating academic performance. This calculator simplifies these calculations, providing instant results without the need for manual computation. Whether you\'re a student, business professional, or just need to quickly work with percentages in daily life, this tool offers a straightforward solution for all your percentage-related calculations.',
        category: 'conversion'
      },
      {
        id: 'temperature',
        path: '/temperature-converter',
        title: 'Temperature Converter – Celsius to Fahrenheit (°C to °F)',
        description: 'Convert temperatures between Celsius and Fahrenheit. Just enter a temperature value to instantly see it in the other unit (°C or °F).',
        metaDescription: 'Convert temperatures between Celsius and Fahrenheit. Just enter a temperature value to instantly see it in the other unit (°C or °F).',
        longDescription: 'The Temperature Converter allows you to easily convert between Celsius (°C) and Fahrenheit (°F), the two most commonly used temperature scales worldwide. Celsius is used in most countries and scientific applications, while Fahrenheit remains the standard for everyday temperature measurement in the United States. The conversion uses the formulas: °F = (°C × 9/5) + 32 and °C = (°F - 32) × 5/9. Some useful reference points: water freezes at 0°C (32°F) and boils at 100°C (212°F), room temperature is about 20-22°C (68-72°F), body temperature is approximately 37°C (98.6°F), and a hot summer day might be 30°C (86°F). This converter is helpful for travelers adjusting to weather forecasts in different countries, cooks following international recipes, or anyone needing to translate between these temperature units for work, study, or everyday life.',
        category: 'conversion'
      }
    ]
  }
];

export const getAllCalculators = (): Calculator[] => {
  const allCalculators: Calculator[] = [];
  calculatorCategories.forEach(category => {
    allCalculators.push(...category.calculators);
  });
  return allCalculators;
};

export const getCalculatorById = (id: string): Calculator | undefined => {
  return getAllCalculators().find(calculator => calculator.id === id);
};

export const getCalculatorByPath = (path: string): Calculator | undefined => {
  return getAllCalculators().find(calculator => calculator.path === path);
};
