
// Format a number with commas and optionally specified decimal places
export const formatNumber = (value: number | string, decimalPlaces: number = 2): string => {
  const num = typeof value === 'string' ? parseFloat(value) : value;
  if (isNaN(num)) return '0';
  
  const options = {
    minimumFractionDigits: 0,
    maximumFractionDigits: decimalPlaces,
  };
  
  return num.toLocaleString(undefined, options);
};

// Finance calculator functions
export const calculateSimpleInterest = (principal: number, rate: number, time: number): number => {
  return (principal * rate * time) / 100;
};

export const calculateCompoundInterest = (
  principal: number,
  rate: number,
  time: number,
  frequency: number = 1
): number => {
  const r = rate / 100;
  const n = frequency;
  const t = time;
  
  const amount = principal * Math.pow(1 + r / n, n * t);
  return amount - principal;
};

export const calculateLoanPayment = (principal: number, rate: number, years: number): number => {
  const monthlyRate = rate / 100 / 12;
  const numberOfPayments = years * 12;
  
  if (monthlyRate === 0) return principal / numberOfPayments;
  
  const payment = principal * (
    monthlyRate * Math.pow(1 + monthlyRate, numberOfPayments)
  ) / (
    Math.pow(1 + monthlyRate, numberOfPayments) - 1
  );
  
  return payment;
};

// Health calculator functions
export const calculateBMI = (weight: number, height: number, unit: 'metric' | 'imperial' = 'metric'): number => {
  if (unit === 'metric') {
    // weight in kg, height in meters
    return weight / (height * height);
  } else {
    // weight in lb, height in inches
    return (weight * 703) / (height * height);
  }
};

export const calculateCalories = (
  weight: number,
  height: number,
  age: number,
  gender: 'male' | 'female',
  activityLevel: number
): number => {
  let bmr;
  
  if (gender === 'male') {
    bmr = 10 * weight + 6.25 * height - 5 * age + 5;
  } else {
    bmr = 10 * weight + 6.25 * height - 5 * age - 161;
  }
  
  return bmr * activityLevel;
};

// Conversion calculator functions
export const lengthConversions = {
  meterToFeet: (meter: number): number => meter * 3.28084,
  feetToMeter: (feet: number): number => feet / 3.28084,
  cmToInch: (cm: number): number => cm / 2.54,
  inchToCm: (inch: number): number => inch * 2.54,
};

export const weightConversions = {
  kgToLbs: (kg: number): number => kg * 2.20462,
  lbsToKg: (lbs: number): number => lbs / 2.20462,
};

export const temperatureConversions = {
  celsiusToFahrenheit: (c: number): number => (c * 9/5) + 32,
  fahrenheitToCelsius: (f: number): number => (f - 32) * 5/9,
};

// Add more calculator functions as needed for other calculator types
